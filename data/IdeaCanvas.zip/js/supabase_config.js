// IdeaCanvas Supabase 연동 설정 파일
// 개발 및 서비스 환경에 맞추어 아래 값을 입력하세요.
// 주의: 이 파일은 프로젝트를 Git 등에 올릴 때 제외(.gitignore에 등록)하는 것이 안전합니다.

const CONFIG = {
    // Supabase 프로젝트 URL (예: "https://abcdefghijkl.supabase.co")
    SUPABASE_URL: "여기에 url을 붙여넣기 하고, supabase.co로 끝나도록 해주세요",

    // Supabase Anon API Key (예: "sb_publishable_abcdefghijklmnopqr_stuvwxyz")
    SUPABASE_KEY: "여기에 api key를 붙여넣기 해주세요"
};
